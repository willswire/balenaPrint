README - CUPS on Windows - 2016-08-08
-------------------------------------

This directory contains Visual Studio project and solution files for building
the CUPS library and cupstestppd, ippfind, ippserver, and ipptool utilities on
Windows.
